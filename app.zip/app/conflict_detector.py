import re
from typing import Dict, Any, Optional
from app.models import Decision
from app.gemini_service import gemini

def normalize_text(text: str) -> str:
    s = text.lower()
    s = re.sub(r'postgres\s*sql', 'postgres', s)
    s = re.sub(r'postgresql', 'postgres', s)
    s = re.sub(r'mongo\s*db', 'mongo', s)
    s = re.sub(r'mongodb', 'mongo', s)
    return s

class ConflictDetector:
    def evaluate_conflict(self, proposed_desc: str, historical_decision: Decision) -> Optional[Dict[str, Any]]:
        prompt = f"""You are a strict organizational memory and governance system.
Compare the following historical decision with a newly proposed decision:

[HISTORICAL DECISION] (Scope: {historical_decision.scope_tag}, Date: {historical_decision.created_at})
"{historical_decision.description}"

[NEW PROPOSED DECISION]
"{proposed_desc}"

Does the new decision contradict, reverse, supersede, or conflict with the earlier decision (e.g. switching database technologies from PostgreSQL to MongoDB)?
Respond strictly in JSON format:
{{
    "is_conflict": true or false,
    "severity": "HIGH" or "MEDIUM" or "LOW",
    "explanation": "concise explanation of why this contradicts the prior decision"
}}"""

        data = gemini.generate_json(prompt)
        if data and data.get("is_conflict"):
            return {
                "severity": data.get("severity", "HIGH"),
                "explanation": data.get("explanation", "Detected conflict with prior decision.")
            }

        # Local heuristic fallback
        p_low = normalize_text(proposed_desc)
        h_low = normalize_text(historical_decision.description)
        
        pairs = [
            ("postgres", "mongo"),
            ("aws", "gcp"),
            ("aws", "azure"),
            ("gcp", "azure"),
            ("always", "never"),
            ("use", "deprecate")
        ]
        for t1, t2 in pairs:
            if (t1 in p_low and t2 in h_low) or (t2 in p_low and t1 in h_low):
                new_tech = t1 if (t1 in p_low and t1 not in h_low) else t2
                old_tech = t2 if new_tech == t1 else t1
                return {
                    "severity": "HIGH",
                    "explanation": f"Contradiction detected: Proposed decision to switch to/use '{new_tech}' contradicts prior decision/plan to use '{old_tech}'."
                }

        if any(w in p_low for w in ["switched", "switch", "pivoted", "cancel", "replace", "instead of"]) and any(w in h_low for w in ["postgres", "mongo", "aws", "gcp", "db", "database"]):
            return {
                "severity": "HIGH",
                "explanation": f"Conflict detected: New decision reverses or supersedes earlier direction '{historical_decision.description}'."
            }

        return None