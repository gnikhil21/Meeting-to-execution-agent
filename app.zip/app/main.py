import os
import json
import re
from datetime import datetime, timedelta
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, Body, Response
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy import create_engine, text

from app.models import Base, Meeting, Decision, ActionItem, ConflictLog, ReviewStatus, DecisionStatus
from app.schemas import MeetingIngestRequest, ActionItemApprovalUpdate, ExtractedDecision
from app.memory_engine import MemoryEngine
from app.conflict_detector import ConflictDetector, normalize_text
from app.extractor import TranscriptExtractor, clean_task_title
from app.tracker_adapter import get_tracker
from app.scheduler import NotificationScheduler

DATABASE_URL = "sqlite:///./meeting_agent.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base.metadata.create_all(bind=engine)
DIGEST_HTML_PATH = os.path.join(os.path.dirname(__file__), "digest.html")

def auto_migrate_db():
    try:
        with engine.connect() as conn:
            res = conn.execute(text("PRAGMA table_info(action_items)")).fetchall()
            cols = [r[1] for r in res]
            for c, t in [("is_update", "BOOLEAN DEFAULT 0"), ("target_existing_task_id", "INTEGER"), ("old_values_json", "TEXT")]:
                if c not in cols:
                    conn.execute(text(f"ALTER TABLE action_items ADD COLUMN {c} {t}"))
            
            res2 = conn.execute(text("PRAGMA table_info(conflict_logs)")).fetchall()
            cols2 = [r[1] for r in res2]
            for c, t in [("affected_task_id", "INTEGER"), ("affected_tracker_task_id", "VARCHAR(100)")]:
                if c not in cols2:
                    conn.execute(text(f"ALTER TABLE conflict_logs ADD COLUMN {c} {t}"))
            conn.commit()
    except Exception as e:
        print(f"Migration check: {e}")

auto_migrate_db()

app = FastAPI(title="Meeting-to-Execution Agent")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

tracker = get_tracker()
conflict_detector = ConflictDetector()
scheduler = NotificationScheduler()

def find_matching_existing_task(db: Session, task_title: str) -> ActionItem | None:
    existing_tasks = db.query(ActionItem).filter(
        ActionItem.is_update == False
    ).order_by(ActionItem.id.desc()).all()

    norm_target = re.sub(r'[^\w\s]', '', normalize_text(task_title)).split()
    target_words = set(w for w in norm_target if w not in ('the', 'a', 'an', 'to', 'for', 'of', 'in', 'with'))

    for task in existing_tasks:
        norm_task = re.sub(r'[^\w\s]', '', normalize_text(task.title)).split()
        task_words = set(w for w in norm_task if w not in ('the', 'a', 'an', 'to', 'for', 'of', 'in', 'with'))
        if not target_words or not task_words:
            continue
        overlap = len(target_words & task_words) / min(len(target_words), len(task_words))
        if overlap >= 0.50 or task.title.lower() in task_title.lower() or task_title.lower() in task.title.lower():
            return task
    return None

@app.post("/api/meetings/ingest")
def ingest_meeting(payload: MeetingIngestRequest, db: Session = Depends(get_db)):
    raw = payload.transcript_text or ""
    lines = TranscriptExtractor.parse_raw_transcript(raw)
    
    meeting = Meeting(title=payload.title, raw_transcript=raw)
    db.add(meeting)
    db.commit()
    db.refresh(meeting)

    formatted_transcript = "\n".join([f"{l.speaker}: {l.text}" for l in lines])
    extracted = TranscriptExtractor.extract_entities(formatted_transcript)
    memory = MemoryEngine(db)
    
    # Preserve architectural commitments as decisions in memory
    arch_keywords = ["postgres", "mongo", "aws", "gcp", "azure", "mysql", "redis", "sqlite"]
    for act in extracted.action_items:
        act_norm = normalize_text(f"{act.title} {act.description or ''}")
        for kw in arch_keywords:
            if kw in act_norm:
                covered = any(kw in normalize_text(d.description) for d in extracted.decisions)
                if not covered:
                    extracted.decisions.append(
                        ExtractedDecision(
                            scope_tag="database" if kw in ["postgres", "mongo", "mysql", "redis", "sqlite"] else "infra",
                            description=f"Use {kw.capitalize()} for {clean_task_title(act.title)}",
                            rationale=f"Committed in meeting by {act.owner}"
                        )
                    )

    flagged_conflicts = []
    created_decisions = []

    # 1. Store decisions & detect conflicts
    for dec in extracted.decisions:
        similar = memory.search_similar_decisions(dec.description, top_k=5, threshold=0.25)
        new_dec = memory.store_decision(meeting.id, dec.scope_tag, dec.description, dec.rationale or "")
        created_decisions.append(new_dec)

        for old_dec, _ in similar:
            conflict = conflict_detector.evaluate_conflict(dec.description, old_dec)
            if conflict:
                # Find the existing task related to the contradicted decision (strictly from prior meetings)
                affected_task = db.query(ActionItem).filter(
                    ActionItem.meeting_id == old_dec.meeting_id,
                    ActionItem.is_update == False
                ).first()

                if not affected_task:
                    old_norm = normalize_text(old_dec.description)
                    for kw in ["postgres", "mongo", "aws", "gcp", "database"]:
                        if kw in old_norm:
                            affected_task = db.query(ActionItem).filter(
                                ActionItem.meeting_id != meeting.id,
                                ActionItem.title.ilike(f"%{kw}%"),
                                ActionItem.is_update == False
                            ).order_by(ActionItem.id.desc()).first()
                            if affected_task:
                                break

                # Tag the real live tracker ID if available, otherwise TASK-{id}
                tag_id = None
                if affected_task:
                    tag_id = affected_task.tracker_task_id or f"TASK-{affected_task.id}"

                clog = ConflictLog(
                    proposed_decision_id=new_dec.id,
                    existing_decision_id=old_dec.id,
                    severity=conflict["severity"],
                    explanation=conflict["explanation"],
                    affected_task_id=affected_task.id if affected_task else None,
                    affected_tracker_task_id=tag_id
                )
                db.add(clog)
                flagged_conflicts.append(conflict["explanation"])
    db.commit()

    # 2. Process Action Items
    created_actions = []
    for act in extracted.action_items:
        clean_header = clean_task_title(act.title)
        clean_owner = act.owner.strip()

        deadline_dt = datetime.utcnow() + timedelta(days=1)
        if act.deadline:
            try:
                deadline_dt = datetime.fromisoformat(act.deadline)
            except Exception:
                pass

        existing_matched = find_matching_existing_task(db, clean_header)

        if existing_matched:
            old_deadline_str = existing_matched.deadline.strftime("%Y-%m-%d") if existing_matched.deadline else "None"
            new_deadline_str = deadline_dt.strftime("%Y-%m-%d") if deadline_dt else "None"
            owner_changed = (existing_matched.owner.lower() != clean_owner.lower())
            deadline_changed = (old_deadline_str != new_deadline_str)
            title_changed = (existing_matched.title.lower() != clean_header.lower())

            if owner_changed or deadline_changed or title_changed:
                old_info = {
                    "old_owner": existing_matched.owner,
                    "old_deadline": old_deadline_str,
                    "ticket_id": existing_matched.tracker_task_id or f"TASK-{existing_matched.id}"
                }
                update_item = ActionItem(
                    meeting_id=meeting.id,
                    title=clean_header,
                    description=act.description or clean_header,
                    owner=clean_owner,
                    deadline=deadline_dt,
                    review_status=ReviewStatus.PENDING,
                    is_update=True,
                    target_existing_task_id=existing_matched.id,
                    tracker_task_id=existing_matched.tracker_task_id,
                    old_values_json=json.dumps(old_info),
                    reminder_sent=False
                )
                db.add(update_item)
                created_actions.append(update_item)
            continue

        pending_dup = db.query(ActionItem).filter(
            ActionItem.title.ilike(clean_header),
            ActionItem.owner.ilike(clean_owner),
            ActionItem.review_status == ReviewStatus.PENDING
        ).first()
        if pending_dup:
            continue

        item = ActionItem(
            meeting_id=meeting.id,
            title=clean_header,
            description=act.description or clean_header,
            owner=clean_owner,
            deadline=deadline_dt,
            review_status=ReviewStatus.PENDING,
            is_update=False,
            reminder_sent=False
        )
        db.add(item)
        created_actions.append(item)

    db.commit()

    return {
        "meeting_id": meeting.id,
        "decisions_count": len(created_decisions),
        "actions_staged": len(created_actions),
        "conflicts_detected": flagged_conflicts
    }

@app.get("/api/review/queue")
def get_review_queue(db: Session = Depends(get_db)):
    pending = db.query(ActionItem).filter(ActionItem.review_status == ReviewStatus.PENDING).all()
    approved = db.query(ActionItem).filter(
        ActionItem.review_status == ReviewStatus.APPROVED,
        ActionItem.is_update == False
    ).order_by(ActionItem.id.desc()).all()
    conflicts = db.query(ConflictLog).filter(ConflictLog.resolved == False).all()
    
    conflict_data = []
    for c in conflicts:
        prop = db.query(Decision).filter(Decision.id == c.proposed_decision_id).first()
        old = db.query(Decision).filter(Decision.id == c.existing_decision_id).first()

        # Dynamically resolve and sync the true current tracker ticket ID
        live_task = None
        if c.affected_task_id:
            live_task = db.query(ActionItem).filter(ActionItem.id == c.affected_task_id).first()
        if not live_task and c.affected_tracker_task_id:
            live_task = db.query(ActionItem).filter(ActionItem.tracker_task_id == c.affected_tracker_task_id).first()

        current_ticket_id = c.affected_tracker_task_id
        if live_task:
            if live_task.tracker_task_id:
                current_ticket_id = live_task.tracker_task_id
                if c.affected_tracker_task_id != live_task.tracker_task_id:
                    c.affected_tracker_task_id = live_task.tracker_task_id
                    db.commit()
            elif not current_ticket_id:
                current_ticket_id = f"TASK-{live_task.id}"

        conflict_data.append({
            "conflict_id": c.id,
            "severity": c.severity,
            "explanation": c.explanation,
            "new_decision": prop.description if prop else (c.explanation or "New decision"),
            "previous_decision": old.description if old else "Historical baseline",
            "affected_tracker_task_id": current_ticket_id
        })

    pending_list = []
    for a in pending:
        old_val = json.loads(a.old_values_json) if a.old_values_json else None
        pending_list.append({
            "id": a.id,
            "title": a.title,
            "description": a.description,
            "owner": a.owner,
            "deadline": a.deadline.strftime("%Y-%m-%d") if a.deadline else "Tomorrow",
            "is_update": bool(a.is_update),
            "target_ticket_id": a.tracker_task_id,
            "old_values": old_val
        })

    return {
        "pending_action_items": pending_list,
        "approved_tickets": [
            {
                "id": a.id,
                "tracker_task_id": a.tracker_task_id or f"TASK-{a.id}",
                "title": a.title,
                "owner": a.owner,
                "deadline": a.deadline.strftime("%Y-%m-%d") if a.deadline else "Tomorrow",
                "status": a.tracker_status or "SYNCED"
            } for a in approved
        ],
        "active_conflicts": conflict_data
    }

@app.post("/api/review/action-items/{item_id}")
def approve_or_reject_action_item(item_id: int, update: ActionItemApprovalUpdate, db: Session = Depends(get_db)):
    item = db.query(ActionItem).filter(ActionItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Action item not found")

    new_status = ReviewStatus(update.review_status)
    item.review_status = new_status

    if new_status == ReviewStatus.APPROVED:
        due_str = item.deadline.strftime("%Y-%m-%d") if item.deadline else ""
        
        if item.is_update and item.target_existing_task_id:
            target = db.query(ActionItem).filter(ActionItem.id == item.target_existing_task_id).first()
            if target:
                target.owner = item.owner
                target.deadline = item.deadline
                target.title = item.title
                tracker.update_task(
                    task_id=target.tracker_task_id or f"TASK-{target.id}",
                    title=target.title,
                    assignee=target.owner,
                    due_date=due_str
                )
        else:
            if not item.tracker_task_id or item.tracker_status != "SYNCED":
                sync_result = tracker.create_task(
                    title=item.title,
                    description=item.description or "",
                    assignee=item.owner,
                    due_date=due_str
                )
                item.tracker_task_id = sync_result.get("id") or f"TASK-{item.id}"
                item.tracker_status = sync_result.get("status") or "SYNCED"

    db.commit()
    return {"id": item.id, "review_status": item.review_status, "tracker_task_id": item.tracker_task_id}

@app.post("/api/review/conflicts/{conflict_id}/resolve")
def resolve_conflict(conflict_id: int, update_ticket: bool = True, payload: Optional[dict] = Body(default=None), db: Session = Depends(get_db)):
    conflict = db.query(ConflictLog).filter(ConflictLog.id == conflict_id).first()
    if not conflict:
        raise HTTPException(status_code=404, detail="Conflict not found")

    res_notes = "Superseded by team decision"
    if payload and isinstance(payload, dict):
        res_notes = payload.get("notes", res_notes)

    conflict.resolved = True
    conflict.resolution_notes = res_notes

    # Supersede historical decision
    if conflict.existing_decision_id:
        old_dec = db.query(Decision).filter(Decision.id == conflict.existing_decision_id).first()
        if old_dec:
            old_dec.status = DecisionStatus.SUPERSEDED

    # Approve and update the corresponding ticket in the database and live tracker
    if update_ticket:
        target_task = None
        if conflict.affected_task_id:
            target_task = db.query(ActionItem).filter(ActionItem.id == conflict.affected_task_id).first()
        if not target_task and conflict.affected_tracker_task_id:
            target_task = db.query(ActionItem).filter(ActionItem.tracker_task_id == conflict.affected_tracker_task_id).first()
        if not target_task and conflict.affected_tracker_task_id and conflict.affected_tracker_task_id.startswith("TASK-"):
            try:
                t_pk = int(conflict.affected_tracker_task_id.replace("TASK-", ""))
                target_task = db.query(ActionItem).filter(ActionItem.id == t_pk).first()
            except Exception:
                pass

        if target_task:
            new_dec = db.query(Decision).filter(Decision.id == conflict.proposed_decision_id).first()
            new_act = None
            if new_dec and new_dec.meeting_id:
                new_act = db.query(ActionItem).filter(
                    ActionItem.meeting_id == new_dec.meeting_id,
                    ActionItem.id != target_task.id
                ).first()

            if new_act and new_act.title:
                updated_title = f"[UPDATED] {clean_task_title(new_act.title)}"
                if new_act.owner:
                    target_task.owner = new_act.owner
            elif new_dec:
                updated_title = f"[UPDATED] {clean_task_title(new_dec.description)}"
            else:
                updated_title = "[UPDATED] New Direction"

            target_task.title = updated_title
            target_task.description = f"Updated following conflict resolution: {res_notes}"
            target_task.review_status = ReviewStatus.APPROVED

            due_str = target_task.deadline.strftime("%Y-%m-%d") if target_task.deadline else ""

            # Update existing tracker ticket or create if not yet synced
            if target_task.tracker_task_id:
                tracker.update_task(
                    task_id=target_task.tracker_task_id,
                    title=target_task.title,
                    description=target_task.description,
                    assignee=target_task.owner,
                    due_date=due_str
                )
            else:
                sync_res = tracker.create_task(
                    title=target_task.title,
                    description=target_task.description,
                    assignee=target_task.owner,
                    due_date=due_str
                )
                target_task.tracker_task_id = sync_res.get("id") or f"TASK-{target_task.id}"
                target_task.tracker_status = sync_res.get("status") or "SYNCED"

            conflict.affected_tracker_task_id = target_task.tracker_task_id

            # Clear out redundant pending update card staged for this task
            if new_act and (new_act.is_update or new_act.target_existing_task_id == target_task.id):
                new_act.review_status = ReviewStatus.APPROVED
                new_act.tracker_task_id = target_task.tracker_task_id
                new_act.tracker_status = target_task.tracker_status

    db.commit()
    return {"status": "RESOLVED", "conflict_id": conflict_id, "updated_ticket": conflict.affected_tracker_task_id}

@app.get("/api/notifications/reminders")
def run_deadline_reminders(db: Session = Depends(get_db)):
    reminders = scheduler.check_deadline_reminders(db)
    return {"dispatched_reminders": reminders, "reminders": reminders}

@app.get("/api/digests/weekly")
def get_weekly_digests(db: Session = Depends(get_db)):
    return {"weekly_digests": scheduler.generate_weekly_digest(db)}

INDEX_HTML_PATH = os.path.join(os.path.dirname(__file__), "index.html")

@app.get("/", response_class=HTMLResponse)
def index_ui(response: Response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    if os.path.exists(INDEX_HTML_PATH):
        with open(INDEX_HTML_PATH, "r", encoding="utf-8") as f:
            return f.read()
    return "<h1>Meeting Agent Running</h1>"

@app.post("/api/tracker/tickets/{ticket_id}/close")
def close_ticket_endpoint(ticket_id: str, db: Session = Depends(get_db)):
    """Closes an active ticket in the local database and the tracker adapter."""
    item = db.query(ActionItem).filter(
        (ActionItem.tracker_task_id == ticket_id) | 
        (ActionItem.id == (int(ticket_id) if ticket_id.isdigit() else -1))
    ).first()
    if not item:
        raise HTTPException(status_code=404, detail="Ticket not found")

    item.tracker_status = "CLOSED"
    tracker.close_task(item.tracker_task_id or f"TASK-{item.id}")
    db.commit()
    return {"status": "CLOSED", "ticket_id": item.tracker_task_id or f"TASK-{item.id}"}

@app.post("/api/tracker/tickets/{ticket_id}/reopen")
def reopen_ticket_endpoint(ticket_id: str, db: Session = Depends(get_db)):
    """Reopens a closed ticket."""
    item = db.query(ActionItem).filter(
        (ActionItem.tracker_task_id == ticket_id) | 
        (ActionItem.id == (int(ticket_id) if ticket_id.isdigit() else -1))
    ).first()
    if not item:
        raise HTTPException(status_code=404, detail="Ticket not found")

    item.tracker_status = "SYNCED"
    db.commit()
    return {"status": "REOPENED", "ticket_id": item.tracker_task_id or f"TASK-{item.id}"}

@app.get("/digest", response_class=HTMLResponse)
def digest_page(response: Response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    if os.path.exists(DIGEST_HTML_PATH):
        with open(DIGEST_HTML_PATH, "r", encoding="utf-8") as f:
            return f.read()
    return "<h1>Digest page not found</h1>"